# UDCT v7.14 Exploratory Findings: The p=1.5 Boundary in QUMOND

**Author:** Won Shik Paik (Independent Researcher, Auckland, New Zealand)  
**Status:** Exploratory research note; not preregistered or confirmatory.  
**Reserved Zenodo DOI:** 10.5281/zenodo.23695048 (registration pending publication)  
**GitHub:** https://github.com/wspaik5/UDCT_v7.14_Exploratory_p1.5_Boundary

## Main paper

`UDCT_v714_p15_FINAL_SECTION_NUMBERS_FIXED.pdf` is the current 15-page paper with Future Directions before Conclusions, two distinct reference sections, and Appendices A–G. The section-number correction does not alter the reported scientific findings.

## Scientific scope

For the specified isolated spherical simple-QUMOND Plummer-field and tracer family, the leading central asymptotic second-derivative coefficient cancels at p=1.5. The Osipkov–Merritt (OM) inversion separately shows a model-specific *local*, finite-energy tangency near r_a/a = 0.4664667874 at p=1.5. The archived numerical audits support a smooth local critical-radius curve around that exponent. These are exploratory model-level results, not a universal QUMOND threshold, a proof of global DF positivity, a stability theorem, or a direct Hydrus I stellar-velocity likelihood fit.

## Paper structure

- Mathematical framework, asymptotic derivation, OM inversion, quantitative critical curve and numerical cross-checks
- Audit evidence ledger, interpretation, observational boundaries, limitations, roadmap
- Near-term and long-term Future Directions, then Conclusions
- References — External Scholarly Literature
- References — UDCT Research Records and Provenance
- Appendices A–F: detailed Audits 01–06; Appendix G: reproducibility and provenance

## Source archives and reproducibility

The source materials for the synthesis are:

1. `7.14 Hessian 1~25.zip` — exploratory Steps 01–25
2. `7.14 Hessian 26~50.zip` — exploratory Steps 26–50
3. `7.14 Exploratory audit 1~6.zip` — exploratory Audits 01–06

The current **paper-and-changelog ZIP is a publication-document bundle, not the complete computational source archive**. To reproduce the numerical calculations, obtain the three source archives and their contained Python scripts, inputs, and outputs; see the provenance statement and Appendix G in the paper. The separately archived Audit 06 package contains the local curve/optimizer numerical checks. Do not treat algorithmic agreement using a shared physical kernel as an independent physics validation.

## Planned publication sequence

Exploratory Findings (this paper) -> separately frozen v7.14 Preregistration -> post-registration execution and audit. Binary systems, merging clusters such as Bullet Cluster, and cross-scale invariance are long-term extensions only.

## License and citation

Zenodo draft metadata currently indicates CC BY 4.0 for the publication. Cite the author, paper title, year, and DOI **after** Zenodo publication activates the reserved DOI. Before publication, cite this as an unpublished exploratory research note and refer to the GitHub repository.

## Package files

- `UDCT_v714_p15_FINAL_SECTION_NUMBERS_FIXED.pdf` — current paper
- `README.md` — this file
- `CHANGELOG.txt` — section renumbering record
